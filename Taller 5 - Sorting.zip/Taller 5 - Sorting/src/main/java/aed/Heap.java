package aed;

public class Heap {
    private Router[] heap;
    private int P;

    public Heap(int p) { //cantidad de partidos
        heap = new Router[p]; // O(P)
        P = p; // O(1)
    }

    // Complejidad : O(P)

    private void swap(Router[] h, int a, int b) {
        if (h[a].getTrafico() > h[b].getTrafico()) { // O(1) //verificamos que siempre se cumpla que h[b] >=h[a] (que el más grande sea el elemento en la posición b)
            Router guardar = h[a]; //para que no se pierda el valor de h en la posición a // O(1)
            h[a] = h[b]; // O(1)
            h[b] = guardar; // O(1)
        }
    }

    // Complejidad : O(1)
    // esta función intercambia nodos si fuera necesario

    public Heap(Router[] h) {
        int i = h.length - 1; //arrancamos en el último elemento // O(1)
        P = h.length; // O(|h|)
        heap = h; // O(|h|)

        if (i == 1) { // O(1)
            swap(h, i, padre(i)); // O(1) //recordar que swap tiene dentro un if. solo swapea si el elemento de la posición padre(i) es más chico que el de i
        } else if (padre(i - 1) != padre(i)) { // O(1) //caso 1 hijo. solo un elemento (el último) puede no tener hermano
            swap(h, i, padre(i)); // O(1)
            i = i - 1; // O(1) //para empezar el ciclo siguiente desde donde todos los elementos tienen hermanos
        }
        while (i > 0) { // O(|h|/2)
            int elMasGrande = i; // O(1) 
            if (heap[i].compareTo(heap[i - 1]) == -1) { // O(1) //nos quedamos con el índice del hijo más grande como elMasGrande
                elMasGrande = i - 1; // O(1)
            }
            swap(heap, elMasGrande, padre(elMasGrande)); // O(1) // el swap verifica que se swapean solamente cuando elmasGrande es mas grande que padre(elMasGrande)
            bajar(elMasGrande); // O(log(|h|)) //reorganizamos el heap
            i = i - 2; //vamos de 2 en 2 porque cuando estamos en este ciclo ya sabemos que la posición i-1 es hermana de i
        }
    }

    // Complejidad : O(|h|/2) * O(log(|h|)) = O(P/2) * O(log(P)) =(por complejidad dada en la teorica del algoritmo de Floyd) O(P)

    private int hijoDerecho(int i) { // O(1)
        return 2 * i + 2; // O(1) //posición del hijo derecho de un nodo del heap en un array
    }

    // Complejidad : O(1)

    private int hijoIzquierdo(int i) { // O(1)
        return 2 * i + 1; // O(1) //posición del hijo izquierdo de un nodo del heap en un array
    }

    // Complejidad : O(1)

    private int padre(int i) { // O(1)
        return (i - 1) / 2; // O(1) //posición del padre de un nodo del heap en un array
    }

    // Complejidad : O(1)

    private int hijoMasGrande(int pos) {
        int res = 99; //inicializamos a res con algo random
        if (hijoDerecho(pos) < P) { //si la posición del hijo derecho de pos es menor que la cantidad de partidos
            if (heap[hijoIzquierdo(pos)].getTrafico() < (heap[hijoDerecho(pos)].getTrafico())) { //si la posición del hijo derecho de pos es mayor que la del izquierdo
                res = hijoDerecho(pos); //nos quedamos con la posición mayor; en este caso, el hijo derecho
            } else {
                res = hijoIzquierdo(pos); //caso contrario, el hijo izquierdo
            }
        } else { //si no, devolvemos al hijo izquierdo de pos.Basicamente si ambos hijos pertencen al arbol(ambas posiciones menores al cap P), entonces nos quedamos con el mas grande de los dos hijos. En caso de que no haya hijo derecho, nos quedamos simepre por default con el hijo izquierdo. 
            res = hijoIzquierdo(pos);
        }
        return res;
    }

    // Complejidad : O(1)
    // esta función encuentra quién es el hijo más grande, si es que tiene, para todos los elementos. 

    private void bajar(int pos) { //comenzamos por la posicion pos
        while (hijoIzquierdo(pos) < P) { // O(log(l)) lo que está dentro de la guarda // mientras que la posición del hijo izquierdo de pos sea menor que la cantidad de partidos y que la posición del hijo más grande 
            int posHijoGrande = hijoMasGrande(pos); // O(1)
            swap(heap, posHijoGrande, pos); // O(1) // intercambiarlos, al nodo con su hijo más grande. 
            pos = posHijoGrande; // O(1)
        }
    }

    public int maximo_t(){
        return heap[0].getTrafico();
    }

    public Router desencolar() {
        P--;
        Router res = heap[0];
        heap[0] = heap[P];
        bajar(0); 
        return res;
    }
}
   
 
