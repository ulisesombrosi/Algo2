package aed;

public class InternetToolkit {
    public InternetToolkit() {
    }

    public Fragment[] tcpReorder(Fragment[] fragments) {
        int i = 1;
        while (i < fragments.length) {
            if (fragments[i].compareTo(fragments[i-1]) > -1){
                
            } else {
                Fragment f = fragments[i];
                fragments[i] = fragments[i - 1];
                fragments[i - 1] = f;
                boolean ordenado = false;
                int j = i - 1;
                while (!ordenado && j > 0) {
                    if (fragments[j].compareTo(fragments[j - 1]) == -1) {
                        Fragment f1 = fragments[j];
                        fragments[j] = fragments[j - 1];
                        fragments[j - 1] = f1;
                        j--;
                    } else {
                        ordenado = true;
                    }
                }

            }
            i++;
        }
        return fragments;
    }

    public Router[] kTopRouters(Router[] routers, int k, int umbral) {
        Heap h = new Heap(routers);
        Router[] res = new Router[k];
        for (int i = 0; i < k; i++) {
            Router r = h.desencolar();
            if (r.getTrafico() > umbral) {
                res[i] = r;
            } else {
                i = k;
            }
        }
        return res;
    }

    public IPv4Address[] sortIPv4(String[] ipv4) {
        // IMPLEMENTAR
        return null;
    }

}
